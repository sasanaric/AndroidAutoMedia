package com.example.androidautomedia;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.ContentResolver;
import android.content.pm.PackageManager;
import android.database.Cursor;
//import android.media.browse.MediaBrowser.MediaItem;
import android.media.browse.MediaBrowser;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
//import androidx.media.MediaBrowserCompat;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private static final int MY_PERMISSIONS_REQUEST_READ_EXTERNAL_STORAGE = 123; // Choose any unique integer value
    private static final String TAG = "MainActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Check if READ_EXTERNAL_STORAGE permission is granted
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.READ_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {

            // Should we show an explanation?
            if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                    Manifest.permission.READ_EXTERNAL_STORAGE)) {
                // Explain to the user why we need to read the storage
                // You can show a dialog or toast here to explain the purpose
                Log.d(TAG, "Explanation for needing READ_EXTERNAL_STORAGE permission");
            }

            // Request the permission from the user
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
                    MY_PERMISSIONS_REQUEST_READ_EXTERNAL_STORAGE);

            return;
        }

        // Permission is already granted, proceed with your app logic
        Log.d(TAG, "READ_EXTERNAL_STORAGE permission already granted");
        // Continue with your app logic...
        initializeMP3Files(); // Call your method to initialize MP3 files here
    }

    // Override onRequestPermissionsResult to handle permission request result
    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == MY_PERMISSIONS_REQUEST_READ_EXTERNAL_STORAGE) {
            // If request is cancelled, the result arrays are empty
            if (grantResults.length > 0
                    && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission is granted, continue with your app logic
                Log.d(TAG, "READ_EXTERNAL_STORAGE permission granted");
                // Continue with your app logic...
                initializeMP3Files(); // Call your method to initialize MP3 files here
            } else {
                // Permission denied, handle accordingly (e.g., show a message)
                Log.d(TAG, "READ_EXTERNAL_STORAGE permission denied");
                // Handle permission denied...
            }
        }
    }

    // Method to initialize MP3 files
    private void initializeMP3Files() {
//        ArrayList<String> mp3Songs = new ArrayList<>();
//
//        // Query MP3 files using MediaStore
//        ContentResolver contentResolver = getContentResolver();
//        Uri uri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
//        String[] projection = {MediaStore.Audio.Media.TITLE};
//        String selection = MediaStore.Audio.Media.IS_MUSIC + " != 0";
//        String sortOrder = MediaStore.Audio.Media.TITLE + " ASC";
//
//        try (Cursor cursor = contentResolver.query(uri, projection, selection, null, sortOrder)) {
//            if (cursor != null && cursor.moveToFirst()) {
//                do {
//                    @SuppressLint("Range") String title = cursor.getString(cursor.getColumnIndex(MediaStore.Audio.Media.TITLE));
//                    mp3Songs.add(title);
//                } while (cursor.moveToNext());
//            }
//        } catch (Exception e) {
//            Log.e(TAG, "Error querying MP3 files: " + e.getMessage());
//        }
        ArrayList<MediaItem> mediaItems = new ArrayList<>();

        // Query MP3 files using MediaStore
        ContentResolver contentResolver = getContentResolver();
        Uri uri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        String[] projection = {MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE};
        String selection = MediaStore.Audio.Media.IS_MUSIC + " != 0";
        String sortOrder = MediaStore.Audio.Media.TITLE + " ASC";

        try (Cursor cursor = contentResolver.query(uri, projection, selection, null, sortOrder)) {
            if (cursor != null && cursor.moveToFirst()) {
                do {
                    @SuppressLint("Range") long id = cursor.getLong(cursor.getColumnIndex(MediaStore.Audio.Media._ID));
                    @SuppressLint("Range") String title = cursor.getString(cursor.getColumnIndex(MediaStore.Audio.Media.TITLE));
                    Uri mediaUri = Uri.withAppendedPath(uri, Long.toString(id));
                    MediaItem mediaItem = new MediaBrowser.MediaItem(new MediaDescriptionCompat.Builder()
                            .setMediaId(Long.toString(id))
                            .setTitle(title)
                            .setMediaUri(mediaUri)
                            .build(), MediaBrowser.MediaItem.FLAG_PLAYABLE);
                    mediaItems.add(mediaItem);
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            Log.e(TAG, "Error querying MP3 files: " + e.getMessage());
        }
        // Populate ListView with MP3 files
        ListView listView = findViewById(R.id.list_view);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, mp3Songs);
        listView.setAdapter(adapter);
    }
}
